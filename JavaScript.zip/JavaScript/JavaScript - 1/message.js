function msg() {
alert("Hello ICT Sem-1");
}
